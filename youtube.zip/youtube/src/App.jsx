// src/App.jsx

import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './App.css';

const API_KEY = 'AIzaSyC8SnzdzSpsV7vWEMxuj7QKRrr-WPnGMyM'; // Substitua pela sua chave de API
const CHANNEL_ID = 'UCnZfNrBtDmlwyLGx5ZGwrVA'; // ID do canal Mistery

const App = () => {
  const [videos, setVideos] = useState([]);

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
          params: {
            part: 'snippet',
            channelId: CHANNEL_ID,
            key: API_KEY,
            maxResults: 81, // número máximo de resultados a serem retornados
            type: 'video', // somente vídeos
          },
        });
        setVideos(response.data.items);
      } catch (error) {
        console.error('Erro ao buscar vídeos do YouTube:', error);
      }
    };

    fetchVideos();
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>Aplicação de Vídeos do YouTube</h1>
      </header>
      <main>
        <div className="youtube-videos">
          <h2>Vídeos do Canal Mistery</h2>
          <div className="video-list">
            {videos.map((video) => (
              <div key={video.id.videoId} className="video-item">
                <a
                  href={`https://www.youtube.com/watch?v=${video.id.videoId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <img
                    src={video.snippet.thumbnails.medium.url}
                    alt={video.snippet.title}
                  />
                  <div className="video-info">
                    <p className="video-title">{video.snippet.title}</p>
                    <p className="video-description">{video.snippet.description}</p>
                  </div>
                </a>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
